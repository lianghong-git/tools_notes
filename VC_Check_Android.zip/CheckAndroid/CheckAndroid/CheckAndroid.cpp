// CheckAndroid.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "CheckAndroid.h"
#include <stdio.h>
#include <assert.h>
#include <tlhelp32.h> 
#include <psapi.h>
#pragma   comment(lib,   "psapi.lib ") 
#include <string>
using namespace std;

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


bool CheckAndroidUsbByAdb();

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	CheckAndroidUsbByAdb();

	return 1;
}


//check device as closed loop, No matter has the devi
bool  CheckAndroidUsbByAdb()
{
	const int PIPE_BUFFER_SIZE = 1024;

	TCHAR currentPath[MAX_PATH] = _T("");
	GetCurrentDirectory(sizeof(currentPath), currentPath);
	wstring adbPath(currentPath);
	adbPath.append(L"\\..\\adbfile\\adb.exe");

	HANDLE hReadPipe;
	HANDLE hWritePipe;
	STARTUPINFO          adbProcStartup;
	SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES),NULL, TRUE };
	BOOL bResult = CreatePipe(&hReadPipe, &hWritePipe ,&sa, PIPE_BUFFER_SIZE);
	assert(0 != bResult);

	PROCESS_INFORMATION  adbProcInfo;
	memset(&adbProcInfo, 0, sizeof(PROCESS_INFORMATION));
	memset(&adbProcStartup, 0, sizeof(STARTUPINFO));
	adbProcStartup.cb          = sizeof(STARTUPINFO);
	adbProcStartup.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	adbProcStartup.hStdOutput  = hWritePipe;                                       //���뵽����ܵ���
	adbProcStartup.wShowWindow = SW_HIDE;

	while(1)
	{
		Sleep(1000);

		if(CreateProcess(adbPath.c_str(), L"adb devices", NULL, NULL, TRUE, 0, NULL,
			NULL, &adbProcStartup, &adbProcInfo))                                    //startup adb.exe 
		{
			DWORD dwExitCode = WaitForSingleObject(adbProcInfo.hProcess, 5000);
			if(WAIT_OBJECT_0 != dwExitCode)
			{
				CloseHandle(adbProcInfo.hProcess);
				CloseHandle(adbProcInfo.hThread);
				return false;
			}
		}
		else{
			CloseHandle(adbProcInfo.hProcess);
			CloseHandle(adbProcInfo.hThread);
			return false;
		}
		::OutputDebugString(L"adb.exe�����ɹ�");

		char szFileBuf[PIPE_BUFFER_SIZE] = "";                                //�豸��Ϣadb.exe��ѯ���豸��Ϣ�������뵽�ܵ��У�Ȼ���ȡ��szFileBuf��
		DWORD dwByteRead = 0;
		ReadFile(hReadPipe, szFileBuf, PIPE_BUFFER_SIZE, &dwByteRead, NULL);  //read data from pipe
		::OutputDebugStringA(szFileBuf); 

		if(strlen(szFileBuf)== 0)
		{
			::OutputDebugString(L"�ܵ���ȡΪ��");
		}
	}

	CloseHandle(hWritePipe);
	CloseHandle(hReadPipe);

	return true;
}
//
